import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Graph {
	private final List<List<Integer>> nodes;

	public Graph(int verticesCount) {
		nodes = new ArrayList<>();
		for (int i = 0; i < verticesCount; i++) {
			nodes.add(new ArrayList<>());
		}
	}

	public void addEdge(int x, int y) {
		addDirectedEdge(x, y);
		addDirectedEdge(y, x);
	}

	private void addDirectedEdge(int from, int to) {
		List<Integer> neighbours = nodes.get(from);
		neighbours.add(to);
	}

	public void printDfs(int vertex) {
		Set<Integer> used = new HashSet<>();
		used.add(vertex);
		dfs(vertex, used);
	}

	public void dfs(int vertex, Set<Integer> used) {
		System.out.println(vertex);
		nodes.get(vertex).stream().filter(neighbour -> !used.contains(neighbour)).forEach(neighbour -> {
			used.add(neighbour);
			dfs(neighbour, used);
		});
	}

	public void print() {
		final int[] index = { 0 };
		nodes.forEach(neighbours -> {
			System.out.println(MessageFormat.format("--- {0} ----", index[0]));
			System.out.println();
			neighbours.forEach(System.out::println);
			index[0]++;
		});
	}
}
