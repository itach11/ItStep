import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

public class Startup {

	// 1st task digits implementation
	private static int[] numberDecompiler(String num) {
		int wholeNumber = Integer.parseInt(num);
		int digits[] = new int[num.length()];
		for (int i = digits.length - 1; i >= 0; i--) {
			digits[i] = wholeNumber % 10;
			wholeNumber = wholeNumber / 10;
		}
		return digits;
	}

	// 2.task Recursion bin printing
	private static String decToBin(int N) {
		if (N / 2 == 0)
			return "" + N;
		return decToBin(N / 2) + "" + N % 2;
	}

	// 4th task the spiral Matrix printing
	private static void spiralMatrixPrint(int n) {
		int[][] spiral = new int[n][n];

		int value = 1;

		int minCol = 0;

		int maxCol = n - 1;

		int minRow = 0;

		int maxRow = n - 1;

		while (value <= n * n) {
			for (int i = minRow; i <= maxRow; i++) {
				spiral[i][minCol] = value;

				value++;
			}

			for (int i = minCol + 1; i <= maxCol; i++) {
				spiral[maxRow][i] = value;

				value++;
			}

			for (int i = maxRow - 1; i >= minRow; i--) {
				spiral[i][maxCol] = value;

				value++;
			}

			for (int i = maxCol - 1; i >= minCol + 1; i--) {
				spiral[minRow][i] = value;

				value++;
			}

			minCol++;

			minRow++;

			maxCol--;

			maxRow--;
		}

		// output
		for (int i = 0; i < spiral.length; i++) {
			for (int j = 0; j < spiral.length; j++) {
				System.out.print(spiral[i][j] + "\t");
			}

			System.out.println();
		}
	}

	public static void main(String[] args) {

		// 1st task output
		int digits[] = numberDecompiler("9821");
		System.out.println(Arrays.toString(digits));

		// 2.task output
		System.out.println(decToBin(24445542));

		// 3th task BigInteger out
		BigNumbers bigNums = new BigNumbers();
		bigNums.sumNums("2223232", "13232320");
		// 4th task output
		spiralMatrixPrint(5);

		// Graphs task output with simple graph example
		Graph graph = new Graph(8);
		graph.addEdge(0, 2);
		graph.addEdge(0, 3);
		graph.addEdge(1, 5);
		graph.addEdge(2, 4);
		graph.addEdge(2, 6);
		graph.addEdge(3, 5);
		graph.addEdge(4, 7);
		graph.addEdge(5, 7);
		graph.addEdge(6, 7);
		graph.print();
		// dfs
		graph.printDfs(0);

	}
}
